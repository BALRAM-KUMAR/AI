from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from config import DATABASE_URL  # Update with your actual DATABASE_URL
from typing import AsyncGenerator

# Create the base class for models
Base = declarative_base()

# Create the async engine
engine = create_async_engine(DATABASE_URL, echo=True, future=True)

# Create a session factory that supports async sessions
AsyncSessionLocal = sessionmaker(
    bind=engine, class_=AsyncSession, expire_on_commit=False
)


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()






