import logging
from fastapi import FastAPI, Depends, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.ext.asyncio import async_sessionmaker
from api.routes.users import router as user_router
from api.routes.roles import router as role_router
from api.routes.profile import router as profile_router
from api.routes.posts import router as post_router
from api.routes.posts import sync_view_counts_to_db

from api.routes.comments import router as comment_router
from api.routes.likes import router as like_router
from api.routes.coll_comp import router as coll_comp_router
from db import engine, Base, AsyncSessionLocal
from cache import get_redis_client  # Import Redis client from the cache module
import uvicorn

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI()

# Enable CORS if necessary
origins = ["https://85hmw8tp-3000.inc1.devtunnels.ms", "http://localhost:3000"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(user_router, prefix="/users")
app.include_router(role_router, prefix="/roles")
app.include_router(profile_router, prefix="/api/profiles", tags=["Profiles"])
app.include_router(post_router, prefix="/api/posts", tags=["Posts"])
app.include_router(comment_router, prefix="/api/comments", tags=["Comments"])
app.include_router(like_router, prefix="/api/likes", tags=["Likes"])
app.include_router(coll_comp_router, prefix="/api/coll-comp", tags=["coll && comp"])

from db import get_db
import asyncio
from sqlalchemy.ext.asyncio import AsyncSession

@app.on_event("startup")
async def startup():
    # Create tables in the database
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Database tables created.")

    # Test Redis connection on startup
    try:
        redis = await get_redis_client()
        
        # Create a new session for syncing
        async with AsyncSessionLocal() as session:  # Make sure to replace async_session with your actual session factory
            asyncio.create_task(sync_view_counts_to_db(session, redis))
    except Exception as e:
        logger.error(f"Failed to connect to Redis: {str(e)}")

@app.on_event("shutdown")
async def shutdown():
    await engine.dispose()  # Clean up on shutdown
    logger.info("Database connection closed.")

@app.middleware("http")
async def log_requests(request: Request, call_next):
    body = await request.body()
    logger.debug(f"Request: {request.method} {request.url} - Body: {body.decode()}")

    response = await call_next(request)

    logger.debug(f"Response: {response.status_code} - Body: {response.body.decode() if hasattr(response, 'body') else 'No body'}")

    return response


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
