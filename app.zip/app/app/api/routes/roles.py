# api/routes/roles.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from db import get_db
from schemas.role import RoleOut
from services.role_service import RoleService

router = APIRouter()

@router.get("/roles", response_model=list[RoleOut])
async def get_all_roles(db: AsyncSession = Depends(get_db)):
    return await RoleService.get_all_roles(db=db)

@router.get("/user/{user_id}/roles", response_model=list[RoleOut])
async def get_user_roles(user_id: int, db: AsyncSession = Depends(get_db)):
    return await RoleService.get_user_roles(user_id=user_id, db=db)

@router.post("/user/{user_id}/assign_role")
async def assign_role_to_user(user_id: int, role_name: str, db: AsyncSession = Depends(get_db)):
    return await RoleService.assign_role_to_user(user_id=user_id, role_name=role_name, db=db)

@router.put("/user/{user_id}/update_role")
async def update_user_role(user_id: int, new_role_name: str, db: AsyncSession = Depends(get_db)):
    return await RoleService.update_user_role(user_id=user_id, new_role_name=new_role_name, db=db)
