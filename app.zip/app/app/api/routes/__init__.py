# # api/routes/__init__.py

# from fastapi import APIRouter

# from api.routes.users import router as users_router
# # from .posts import router as posts_router
# # from .products import router as products_router
# # from .comments import router as comments_router
# # from .likes import router as likes_router

# router = APIRouter()

# router.include_router(users_router, prefix="/users", tags=["Users"])
# # router.include_router(posts_router, prefix="/posts", tags=["Posts"])
# # router.include_router(products_router, prefix="/products", tags=["Products"])
# # router.include_router(comments_router, prefix="/comments", tags=["Comments"])
# # router.include_router(likes_router, prefix="/likes", tags=["Likes"])
