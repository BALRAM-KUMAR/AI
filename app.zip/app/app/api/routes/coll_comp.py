from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import IntegrityError
from typing import List, Dict, Any
from models import College, Company  # Assuming models are defined in models.py
from db import get_db  # Dependency for the DB session

router = APIRouter()

# Get College API
@router.get("/get-colleges", response_model=List[Dict[str, Any]])
async def get_colleges(
    session: AsyncSession = Depends(get_db),
    state: str = None,
    district: str = None,
    page: int = 1,
    page_size: int = 10
):
    offset = (page - 1) * page_size

    query = select(College)
    if state:
        query = query.filter(College.state == state)
    if district:
        query = query.filter(College.district == district)

    result = await session.execute(query.offset(offset).limit(page_size))
    colleges = result.scalars().all()

    if not colleges:
        raise HTTPException(status_code=404, detail="No colleges found")

    return [
        {
            "id": college.id,
            "university": college.university,
            "college": college.college,
            "school": college.school,
            "college_type": college.college_type,
            "state": college.state,
            "district": college.district,
        }
        for college in colleges
    ]

# Get Company API
@router.get("/get-companies", response_model=List[Dict[str, Any]])
async def get_companies(
    session: AsyncSession = Depends(get_db),
    location: str = None,
    page: int = 1,
    page_size: int = 10
):
    offset = (page - 1) * page_size

    query = select(Company)
    if location:
        query = query.filter(Company.location.ilike(f"%{location}%"))

    result = await session.execute(query.offset(offset).limit(page_size))
    companies = result.scalars().all()

    if not companies:
        raise HTTPException(status_code=404, detail="No companies found")

    return [
        {
            "id": company.id,
            "name": company.name,
            "short_names": company.short_names,
            "location": company.location,
        }
        for company in companies
    ]

# Add College API
@router.post("/add-college", response_model=Dict[str, Any])
async def add_college(
    college_data: Dict[str, Any],
    session: AsyncSession = Depends(get_db)
):
    try:
        new_college = College(
            university=college_data.get("university"),
            college=college_data.get("college"),
            school=college_data.get("school"),
            college_type=college_data.get("college_type"),
            state=college_data.get("state"),
            district=college_data.get("district"),
        )
        session.add(new_college)
        await session.commit()
        await session.refresh(new_college)
        return {
            "message": "College added successfully",
            "college_id": new_college.id
        }
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=400, detail="College already exists or invalid data")

# Add Company API
@router.post("/add-company", response_model=Dict[str, Any])
async def add_company(
    company_data: Dict[str, Any],
    session: AsyncSession = Depends(get_db)
):
    try:
        new_company = Company(
            name=company_data.get("name"),
            short_names=company_data.get("short_names"),
            location=company_data.get("location"),
        )
        session.add(new_company)
        await session.commit()
        await session.refresh(new_company)
        return {
            "message": "Company added successfully",
            "company_id": new_company.id
        }
    except IntegrityError:
        await session.rollback()
        raise HTTPException(status_code=400, detail="Company already exists or invalid data")
