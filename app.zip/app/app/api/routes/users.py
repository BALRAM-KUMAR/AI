# app/routes/users.py
from db import get_db
from schemas.user import UserCreate, UserOut
from services.user_service import UserService, UserDetails, UserPostService, PostDetailsService,PublicPostService
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.exc import InvalidRequestError
import logging


from fastapi import APIRouter, Depends, HTTPException, Request, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy import func

from sqlalchemy.orm import joinedload, selectinload
from models import User, Profile, Post, UserRole, Product, UserSession, Notification , Tag, PostTag, Comment,Like, followers_association
from typing import Any, Dict, List

router = APIRouter()

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@router.post("/register")
async def register_user(user: UserCreate, db: AsyncSession = Depends(get_db)):
    response = await UserService.register_user(user_data=user, db=db)
    return response

@router.post("/login")
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    print("form data", form_data)
    print(f"Received login request - Username: {form_data.username}, Password: {form_data.password}")
    
    response = await UserService.login_user(
        email=form_data.username, password=form_data.password, db=db
    )
    
    if not response:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    return response



# @router.get("/{user_id}/details", response_model=Dict[str, Any])
# async def get_user_details(user_id: int, session: AsyncSession = Depends(get_db)):
#     try:
#         # Fetch the user and relationships asynchronously
#         result = await session.execute(
#             select(User)
#             .options(
#                 selectinload(User.profile).selectinload(Profile.college),
#                 selectinload(User.profile).selectinload(Profile.company),
#                 selectinload(User.session),
#                 selectinload(User.notifications),
#             )
#             .where(User.id == user_id)
#         )
#         user = result.scalars().first()

#         if not user:
#             raise HTTPException(status_code=404, detail="User not found")

#         # Fetch followers with details
#         followers_query = await session.execute(
#             select(User)
#             .join(followers_association, followers_association.c.follower_id == User.id)
#             .where(followers_association.c.followed_id == user_id)
#         )
#         followers = [
#             {
#                 "user_id": follower.id,
#                 "username": follower.name,
#                 "profile_pic": follower.profile.image if follower.profile else "default_image.jpg",
#             }
#             for follower in followers_query.scalars().all()
#         ]

#         # Fetch following with details
#         following_query = await session.execute(
#             select(User)
#             .join(followers_association, followers_association.c.followed_id == User.id)
#             .where(followers_association.c.follower_id == user_id)
#         )
#         following = [
#             {
#                 "user_id": following_user.id,
#                 "username": following_user.name,
#                 "profile_pic": following_user.profile.image if following_user.profile else "default_image.jpg",
#             }
#             for following_user in following_query.scalars().all()
#         ]

#         # Safely access relationships
#         user_data = {
#             "user": {
#                 "id": user.id,
#                 "name": user.name,
#                 "is_profile_public": user.is_profile_public,
#                 "created_on": user.created_on.isoformat(),
#                 "updated_on": user.updated_on.isoformat() if user.updated_on else None,
#             },
#             "profile": {
#                 "bio": user.profile.bio if user.profile else None,
#                 "image": user.profile.image if user.profile else None,
#                 "sex": user.profile.sex if user.profile else None,
#                 "college": {
#                     "university": user.profile.college.university if user.profile and user.profile.college else None,
#                     "college": user.profile.college.college if user.profile and user.profile.college else None,
#                     "school": user.profile.college.school if user.profile and user.profile.college else None,
#                     "state": user.profile.college.state if user.profile and user.profile.college else None,
#                     "district": user.profile.college.district if user.profile and user.profile.college else None,
#                 } if user.profile else None,
#                 "company": {
#                     "name": user.profile.company.name if user.profile and user.profile.company else None,
#                     "location": user.profile.company.location if user.profile and user.profile.company else None,
#                     "short_name": user.profile.company.short_names if user.profile and user.profile.company else None,
#                 } if user.profile else None,
#             },
#             "session": {
#                 "status": user.session.status if user.session else "offline",
#                 "last_active": user.session.last_active.isoformat() if user.session and user.session.last_active else None,
#             },
#             "notifications": [
#                 {
#                     "message": notification.message,
#                     "is_read": notification.is_read,
#                     "created_on": notification.created_on.isoformat(),
#                 }
#                 for notification in user.notifications
#             ] or [],
#             "followers": {
#                 "count": len(followers),
#                 "list": followers,  # List of follower details
#             },
#             "following": {
#                 "count": len(following),
#                 "list": following,  # List of following details
#             },
#         }
#         return user_data

#     except Exception as e:
#         logger.error(f"Error fetching user details for user_id {user_id}: {e}")
#         raise HTTPException(status_code=500, detail="An unexpected error occurred")


@router.get("/{user_id}/details", response_model=Dict[str, Any])
async def get_user_details(user_id: int, session: AsyncSession = Depends(get_db)):
    try:
        return await UserDetails.fetch_user_details(user_id, session)
    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise HTTPException(status_code=500, detail="An unexpected error occurred")

@router.get("/{user_id}/posts", response_model=List[Dict[str, Any]])
async def get_user_posts(
    user_id: int, session: AsyncSession = Depends(get_db), page: int = 1, page_size: int = 10, sort_by: str = "recent"
):
    return await UserPostService.get_user_posts(user_id=user_id, session=session, page=page, page_size=page_size, sort_by=sort_by)

@router.get("/post/{post_id}", response_model=Dict[str, Any])
async def get_post_details(
    post_id: int, session: AsyncSession = Depends(get_db)
):
    return await PostDetailsService.get_post_details(post_id=post_id, session=session)

@router.get("/public_posts", response_model=List[Dict[str, Any]])
async def get_public_posts(
    session: AsyncSession = Depends(get_db), page: int = 1, page_size: int = 10, sort_by: str = "recent"
):
    return await PublicPostService.get_public_posts(session=session, page=page, page_size=page_size, sort_by=sort_by)

























# @router.get("/{user_id}/posts", response_model=List[Dict[str, Any]])
# async def get_user_posts(user_id: int, session: AsyncSession = Depends(get_db)):
#     try:
#         # Fetch posts and related data
#         result = await session.execute(
#             select(Post)
#             .options(
#                 selectinload(Post.user).selectinload(User.profile),
#                 selectinload(Post.tags).selectinload(PostTag.tag),
#                 selectinload(Post.likes).selectinload(Like.user),
#                 selectinload(Post.comments).selectinload(Comment.user),
#             )
#             .where(Post.user_id == user_id)
#             .order_by(Post.created_on.desc())
#         )
#         posts = result.scalars().all()

#         # Format data
#         post_data = [
#             {
#                 "post_id": post.id,
#                 "post":post.is_post,
#                 "quote":post.is_quote,
#                 "visible_post":post.is_visible_in_profile,
#                 "title": post.title,
#                 "content": post.content,
#                 "bg_color": post.bg_color,
#                 "bg_image": post.bg_image,
#                 "song": post.song,
#                 "video": post.video,
#                 "created_on": post.created_on.isoformat(),
#                 "updated_on": post.updated_on.isoformat() if post.updated_on else None,
#                 "view_count": post.view_count,
#                 "author": {
#                     "user_id": post.user.id,
#                     "name": post.user.name if post.user.is_profile_public else "Anonymous",
#                     "profile_image": post.user.profile.image
#                     if post.user.is_profile_public and post.user.profile
#                     else "default_image.jpg",
#                 },
#                 "tags": [tag.tag.name for tag in post.tags],
#                 "likes_count": len(post.likes),
#                 "comments": [
#                     {
#                         "comment_id": comment.id,
#                         "content": comment.content,
#                         "author": comment.user.name if comment.user.is_profile_public else "Anonymous",
#                         "created_on": comment.created_on.isoformat(),
#                     }
#                     for comment in post.comments
#                 ],
#                 "likes": [
#                     {
#                         "user_id": like.user.id,
#                         "user_name": like.user.name if like.user.is_profile_public else "Anonymous",
#                     }
#                     for like in post.likes
#                 ],
#             }
#             for post in posts
#         ]

#         return post_data

#     except Exception as e:
#         logger.error(f"Error fetching posts for user_id {user_id}: {e}")
#         raise HTTPException(status_code=500, detail="An unexpected error occurred")



# @router.get("/post/{post_id}", response_model=Dict[str, Any])
# async def get_post_details(
#     post_id: int,
#     session: AsyncSession = Depends(get_db)
# ):
#     # Fetch the post with full details
#     result = await session.execute(
#         select(Post)
#         .where(Post.id == post_id)
#         .options(
#             joinedload(Post.user).joinedload(User.profile),
#             joinedload(Post.tags).joinedload(PostTag.tag),
#             joinedload(Post.comments).joinedload(Comment.user),
#             joinedload(Post.likes).joinedload(Like.user)
#         )
#     )

#     post = result.scalar()

#     if not post:
#         raise HTTPException(status_code=404, detail="Post not found")

#     # Format response
#     response_data = {
#         "post_id": post.id,
#         "title": post.title,
#         "content": post.content,
#         "bg_color": post.bg_color,
#         "bg_image": post.bg_image,
#         "song": post.song,
#         "video": post.video,
#         "created_on": post.created_on,
#         "updated_on": post.updated_on,
#         "view_count": post.view_count,
#         "author": {
#             "user_id": post.user.id,
#             "name": post.user.name if post.user.is_profile_public else "Anonymous",  # Adjust based on profile visibility
#             "profile_image": post.user.profile.image if post.user.is_profile_public and post.user.profile else "default_image.jpg"
#         },
#         "tags": [tag.tag.name for tag in post.tags],
#         "likes_count": len(post.likes),
#         "comments": [
#             {
#                 "comment_id": comment.id,
#                 "content": comment.content,
#                 "author": comment.user.name if comment.user.is_profile_public else "Anonymous",  # Adjust comment visibility
#                 "created_on": comment.created_on,
#             }
#             for comment in post.comments
#         ],
#         "likes": [
#             {
#                 "user_id": like.user.id,
#                 "user_name": like.user.name if like.user.is_profile_public else "Anonymous"  # Adjust like visibility
#             }
#             for like in post.likes
#         ]
#     }

#     return response_data


# @router.get("/public_posts", response_model=List[Dict[str, Any]]) 
# async def get_public_posts(
#     session: AsyncSession = Depends(get_db),
#     page: int = 1,
#     page_size: int = 10,
#     sort_by: str = "recent"  # Options: "recent", "trending"
# ):
#     offset = (page - 1) * page_size

#     # Determine sorting order
#     if sort_by == "trending":
#         order_by_clause = Post.view_count.desc()
#     else:
#         order_by_clause = Post.created_on.desc()

#     # Fetch posts with correct ordering and deduplication
#     subquery = (
#         select(Post.id)
#         .order_by(order_by_clause)
#         .offset(offset)
#         .limit(page_size)
#         .subquery()
#     )

#     result = await session.execute(
#         select(Post)
#         .filter(Post.id.in_(subquery))
#         .order_by(order_by_clause)
#         .options(
#             selectinload(Post.user).selectinload(User.profile),
#             selectinload(Post.tags).selectinload(PostTag.tag),
#             selectinload(Post.comments).selectinload(Comment.user),
#             selectinload(Post.likes).selectinload(Like.user)
#         )
#     )

#     posts = result.scalars().all()

#     if not posts:
#         raise HTTPException(status_code=404, detail="No public posts found")

#     # Format response with detailed structure for each post
#     response_data = [
#         {
#             "post_id": post.id,
#             "title": post.title,
#             "content": post.content,
#             "bg_color": post.bg_color,
#             "bg_image": post.bg_image,
#             "song": post.song,
#             "video": post.video,
#             "created_on": post.created_on,
#             "updated_on": post.updated_on,
#             "view_count": post.view_count,
#             "author": {
#                 "user_id": post.user.id,
#                 "name": post.user.name if post.user.is_profile_public else "Anonymous",
#                 "profile_image": post.user.profile.image if post.user.is_profile_public and post.user.profile else "default_image.jpg"
#             },
#             "tags": [tag.tag.name for tag in post.tags],
#             "likes_count": len(post.likes),
#             "comments": [
#                 {
#                     "comment_id": comment.id,
#                     "content": comment.content,
#                     "author": comment.user.name if comment.user.is_profile_public else "Anonymous",
#                     "created_on": comment.created_on,
#                 }
#                 for comment in post.comments
#             ],
#             "likes": [
#                 {
#                     "user_id": like.user.id,
#                     "user_name": like.user.name if like.user.is_profile_public else "Anonymous"
#                 }
#                 for like in post.likes
#             ]
#         }
#         for post in posts
#     ]

#     return response_data








# @router.get("/details", response_model=List[Dict[str, Any]])
# async def get_all_user_details(session: AsyncSession = Depends(get_db)):
#     try:
#         # Query users with related information using joinedload for nested relationships
#         result = await session.execute(
#             select(User)
#             .options(
#                 joinedload(User.profile),  # Load User's profile
#                 joinedload(User.posts).options(
#                     joinedload(Post.tags).joinedload(PostTag.tag)  # Load PostTag.tag
#                 ),
#                 joinedload(User.roles).joinedload(UserRole.role),  # Load User's roles
#                 selectinload(User.products),  # Load User's products
#                 selectinload(User.session),  # Load User's session
#                 selectinload(User.notifications),  # Load User's notifications
#             )
#         )

#         # Using scalars() directly and avoiding .all()
#         users = result.scalars().unique()

#         # Check if no users are found
#         if not users:
#             raise HTTPException(status_code=404, detail="No users found")

#         # Format the user details into a response dictionary
#         all_users_data = []
#         for user in users:
#             user_data = {
#                 "user": {
#                     "id": user.id,
#                     "name": user.name,
#                     "email": user.email,
#                     "mobile_number": user.mobile_number,
#                     "is_profile_public": user.is_profile_public,
#                     "created_on": user.created_on,
#                     "updated_on": user.updated_on,
#                 },
#                 "profile": {
#                     "bio": user.profile.bio if user.profile else None,
#                     "image": user.profile.image if user.profile else None,
#                     "college": user.profile.college if user.profile else None,
#                     "followers": user.profile.followers if user.profile else None,
#                     "followings": user.profile.followings if user.profile else None,
#                 },
#                 "posts": [
#                     {
#                         "id": post.id,
#                         "title": post.title,
#                         "content": post.content,
#                         "created_on": post.created_on,
#                         "updated_on": post.updated_on,
#                         "tags": [tag.tag.name for tag in post.tags if tag.tag],
#                     }
#                     for post in user.posts
#                 ] if user.posts else "No posts available",
#                 "roles": [
#                     {
#                         "role_name": user_role.role.role_name,
#                         "description": user_role.role.description,
#                     }
#                     for user_role in user.roles if user_role.role
#                 ] if user.roles else "No roles available",
#                 "products": [
#                     {
#                         "name": product.name,
#                         "is_gift": product.is_gift,
#                         "is_jewellery": product.is_jewellery,
#                         "original_price": product.original_price,
#                         "discount_price": product.discount_price,
#                     }
#                     for product in user.products
#                 ] if user.products else "No products available",
#                 "session": {
#                     "status": user.session.status if user.session else "offline",
#                     "last_active": user.session.last_active if user.session else None,
#                 },
#                 "notifications": [
#                     {
#                         "message": notification.message,
#                         "is_read": notification.is_read,
#                         "created_on": notification.created_on,
#                     }
#                     for notification in user.notifications
#                 ] if user.notifications else "No Notification available",
#             }

#             all_users_data.append(user_data)

#         return all_users_data

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Internal Server Error: {str(e)}")