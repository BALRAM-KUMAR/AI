# routes/like.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List
from db import get_db
from services.like_service import (
    toggle_like
)
from schemas.like import LikeResponse

router = APIRouter()

# Add or remove a like for a specific post by a user
from pydantic import BaseModel

# Define a request schema for the additional parameters
class LikeRequest(BaseModel):
    username: str
    isprofilepublic: bool

@router.post("/posts/{post_id}/user/{user_id}/like", response_model=dict)
async def like_post(post_id: int, user_id: int, like_request: LikeRequest):
    """
    Toggles like status for a given post by a specific user.
    """
    username = like_request.username
    isprofilepublic = like_request.isprofilepublic
    return await toggle_like(post_id, user_id, username, isprofilepublic)


# # Remove a like from a specific post by a user
# @router.delete("/posts/{post_id}/user/{user_id}/like")
# async def unlike_post(post_id: int, user_id: int, session: AsyncSession = Depends(get_db)):
#     await remove_like(post_id, user_id, session)
#     return {"detail": "Like removed successfully"}

# # Get all likes for a specific post
# @router.get("/posts/{post_id}/likes", response_model=List[LikeResponse])
# async def get_all_likes_for_post(post_id: int, session: AsyncSession = Depends(get_db)):
#     return await get_likes_for_post(post_id, session)

# # Get all likes made by a specific user
# @router.get("/users/{user_id}/likes", response_model=List[LikeResponse])
# async def get_all_likes_by_user(user_id: int, session: AsyncSession = Depends(get_db)):
#     return await get_likes_by_user(user_id, session)
