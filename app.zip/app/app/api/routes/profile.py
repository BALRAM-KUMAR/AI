# routes/profile.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from db import get_db
from services.profile_service import get_profile_by_user_id, create_profile, update_profile, delete_profile, get_all_profiles
from pydantic import BaseModel
from typing import Optional

router = APIRouter()

# Pydantic model for request body validation
class ProfileCreateUpdate(BaseModel):
    bio: Optional[str] = None
    image: Optional[str] = None
    college: Optional[str] = None
    sex: Optional[str] = None
    followers: Optional[int] = None
    followings: Optional[int] = None


@router.get("/profiles/{user_id}")
async def get_profile(user_id: int, session: AsyncSession = Depends(get_db)):
    return await get_profile_by_user_id(user_id, session)


@router.post("/profiles/{user_id}")
async def create_profile_route(user_id: int, profile_data: ProfileCreateUpdate, session: AsyncSession = Depends(get_db)):
    return await create_profile(user_id, profile_data.dict(), session)


@router.put("/profiles/{user_id}")
async def update_profile_route(user_id: int, profile_data: ProfileCreateUpdate, session: AsyncSession = Depends(get_db)):
    return await update_profile(user_id, profile_data.dict(), session)


@router.delete("/profiles/{user_id}")
async def delete_profile_route(user_id: int, session: AsyncSession = Depends(get_db)):
    return await delete_profile(user_id, session)

@router.get("/profiles")
async def get_all_profiles_route(session: AsyncSession = Depends(get_db)):
    return await get_all_profiles(session)
