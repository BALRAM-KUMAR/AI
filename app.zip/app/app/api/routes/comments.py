# routes/comment.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
from db import get_db
from services.comment_service import (
    create_comment_for_post,
    get_comments_for_post,
    get_comment_by_id,
    update_comment_by_id,
    delete_comment_by_id,
)
from schemas.comment import CommentCreate, CommentUpdate, CommentResponse

router = APIRouter()

# Create a comment for a specific post by a user
@router.post("/posts/{post_id}/user/{user_id}/comments", response_model=CommentResponse)
async def create_comment(
    post_id: int,
    user_id: int,
    comment: CommentCreate,
    session: AsyncSession = Depends(get_db),
    parent_id: Optional[int] = None
):
    """
    Creates a comment, reply to a comment, or reply to a reply.

    - `post_id`: ID of the post.
    - `user_id`: ID of the user making the comment.
    - `parent_id`: ID of the parent comment, if this is a reply.
    - `comment`: The content of the comment.
    """
    return await create_comment_for_post(comment.dict(), user_id, post_id, parent_id, session)

# Get all comments for a specific post
@router.get("/posts/{post_id}/comments", response_model=List[CommentResponse])
async def get_all_comments_for_post(post_id: int, session: AsyncSession = Depends(get_db)):
    return await get_comments_for_post(post_id, session)

# Get a specific comment by comment_id
@router.get("/comments/{comment_id}", response_model=CommentResponse)
async def get_comment(comment_id: int, session: AsyncSession = Depends(get_db)):
    return await get_comment_by_id(comment_id, session)

# Update a specific comment by user_id and comment_id
@router.put("/comments/{comment_id}/user/{user_id}", response_model=CommentResponse)
async def update_comment(comment_id: int, user_id: int, comment: CommentUpdate, session: AsyncSession = Depends(get_db)):
    return await update_comment_by_id(comment_id, user_id, comment.dict(exclude_unset=True), session)

# Delete a specific comment by user_id and comment_id
@router.delete("/comments/{comment_id}/user/{user_id}")
async def delete_comment(comment_id: int, user_id: int, session: AsyncSession = Depends(get_db)):
    await delete_comment_by_id(comment_id, user_id, session)
    return {"detail": "Comment deleted successfully"}
