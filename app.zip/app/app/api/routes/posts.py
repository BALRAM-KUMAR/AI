from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from sqlalchemy.ext.asyncio import AsyncSession
from services.post_service import create_post, update_post_by_user
from db import get_db
from models import Post

router = APIRouter()

# Request model for creating or updating posts
class PostCreateUpdate(BaseModel):
    user_id: int
    content: Optional[str] = None
    title: str
    target_user: Optional[str] = None
    song: Optional[str] = None
    video: Optional[str] = None
    bg_color: Optional[str] = None
    bg_image: Optional[str] = None
    tags: List[str] = []
    college_id: Optional[int] = None
    company_id: Optional[int] = None


# Create Post
@router.post("/posts")
async def create_post_route(post_data: PostCreateUpdate, session: AsyncSession = Depends(get_db)):
    try:
        await create_post(post_data.dict(), session)
        return {"message": "Post created successfully"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


# Update Post
@router.put("/posts/{post_id}")
async def update_post_route(post_id: int, post_data: PostCreateUpdate, session: AsyncSession = Depends(get_db)):
    try:
        await update_post_by_user(post_id, post_data.user_id, post_data.dict(), session)
        return {"message": "Post updated successfully"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

from cache import get_redis_client
import asyncio
from typing import Dict
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, Request
from sqlalchemy.future import select

connected_clients: Dict[int, set] = {}

# Dependency to get Redis client
async def get_redis():
    redis = await get_redis_client()
    return redis

@router.post("/posts/{post_id}/view", tags=["Posts"])
async def record_view(post_id: int, request: Request, db: AsyncSession = Depends(get_db), redis=Depends(get_redis)):
    """API endpoint to record a view for a post."""
    client_ip = request.client.host
    cache_key = f"{post_id}:{client_ip}"

    # Avoid duplicate views for the same post-IP combination
    if not await redis.exists(cache_key):
        await redis.set(cache_key, 1, ex=60)  # Cache for 60 seconds
        # Increment Redis view count
        await redis.incrby(f"post:{post_id}:views", 1)
        # Publish to Redis Pub/Sub for real-time update
        await redis.publish("post_views_channel", f"{post_id}:1")

    return {"message": "View recorded"}

@router.websocket("/ws/{post_id}")
async def websocket_view_count(websocket: WebSocket, post_id: int, redis=Depends(get_redis)):
    """WebSocket endpoint for real-time view count updates."""
    await websocket.accept()

    # Add the client to the WebSocket clients list for the post
    if post_id not in connected_clients:
        connected_clients[post_id] = set()
    connected_clients[post_id].add(websocket)

    try:
        # Keep the connection alive and listen for view count changes
        while True:
            await asyncio.sleep(30)  # Keep connection alive
    except WebSocketDisconnect:
        # Remove disconnected client
        connected_clients[post_id].remove(websocket)
        if not connected_clients[post_id]:
            del connected_clients[post_id]

# Background task for syncing Redis view counts to the database
async def sync_view_counts_to_db(session: AsyncSession, redis):
    """Sync Redis view counts to the database periodically."""
    while True:
        async with session.begin():
            posts = await session.execute(select(Post.id, Post.view_count))
            posts = posts.fetchall()
            for post_id, current_view_count in posts:
                redis_key = f"post:{post_id}:views"
                redis_views = await redis.get(redis_key)
                if redis_views:
                    redis_views = int(redis_views)
                    if current_view_count != redis_views:
                        post = await session.execute(select(Post).filter(Post.id == post_id))
                        post = post.scalar_one_or_none()
                        if post:
                            post.view_count = redis_views
                            await session.commit()
        await asyncio.sleep(60)  # Sync every minute

# # Delete a post by user ID
# @router.delete("/posts/{post_id}/user/{user_id}", response_model=dict)
# async def delete_post_by_user_route(post_id: int, user_id: int, session: AsyncSession = Depends(get_db)):
#     return await delete_post_by_user(post_id, user_id, session)

# # Get posts by user and tag
# @router.get("/posts/user/{user_id}/tag/{tag_name}", response_model=List[PostResponse])
# async def get_posts_by_user_and_tag_route(user_id: int, tag_name: str, session: AsyncSession = Depends(get_db)):
#     posts = await get_posts_by_user_and_tag(user_id, tag_name, session)
#     return [PostResponse(
#         id=post.id,
#         user_id=post.user_id,
#         content=post.content,
#         title=post.title,
#         target_user=post.target_user,
#         song=post.song,
#         video=post.video,
#         bg_color=post.bg_color,
#         bg_image=post.bg_image,
#         tags=[tag.name for tag in post.tags]
#     ) for post in posts]
