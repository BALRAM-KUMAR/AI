from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime
from services.product_service import (
    get_all_products,
    get_product_by_id,
    create_product,
    create_product_for_user,
    update_product,
    delete_product,
    get_products_by_user_id,
)
from db import get_db

router = APIRouter()

# Pydantic schema for creating/updating products
class ProductCreateUpdate(BaseModel):
    is_gift: Optional[bool] = False
    is_jewellery: Optional[bool] = False
    image: Optional[str] = None
    link: Optional[str] = None
    name: str
    original_price: Optional[float] = None
    discount_price: Optional[float] = None

# Pydantic schema for response model
class ProductResponse(BaseModel):
    id: int
    user_id: int
    is_gift: bool
    is_jewellery: bool
    image: Optional[str]
    link: Optional[str]
    name: str
    original_price: Optional[float]
    discount_price: Optional[float]
    created_on: datetime

    class Config:
        from_attributes = True

# Create a new product for a specific user
@router.post("/products/user/{user_id}", response_model=ProductResponse)
async def create_product_for_user_route(user_id: int, product_data: ProductCreateUpdate, session: AsyncSession = Depends(get_db)):
    return await create_product_for_user(user_id, product_data.dict(), session)


# Get all products
@router.get("/products", response_model=List[ProductResponse])
async def get_all_products_route(session: AsyncSession = Depends(get_db)):
    return await get_all_products(session)

# Create a new product
@router.post("/products", response_model=ProductResponse)
async def create_product_route(product_data: ProductCreateUpdate, session: AsyncSession = Depends(get_db)):
    return await create_product(product_data.dict(), session)

# Get a specific product by ID
@router.get("/products/{product_id}", response_model=ProductResponse)
async def get_product_by_id_route(product_id: int, session: AsyncSession = Depends(get_db)):
    product = await get_product_by_id(product_id, session)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product

# Get all products by a specific user
@router.get("/products/user/{user_id}", response_model=List[ProductResponse])
async def get_products_by_user_id_route(user_id: int, session: AsyncSession = Depends(get_db)):
    return await get_products_by_user_id(user_id, session)

# Update a product by ID
@router.put("/products/{product_id}", response_model=ProductResponse)
async def update_product_route(product_id: int, product_data: ProductCreateUpdate, session: AsyncSession = Depends(get_db)):
    updated_product = await update_product(product_id, product_data.dict(), session)
    if not updated_product:
        raise HTTPException(status_code=404, detail="Product not found")
    return updated_product

# Delete a product by ID
@router.delete("/products/{product_id}", response_model=dict)
async def delete_product_route(product_id: int, session: AsyncSession = Depends(get_db)):
    result = await delete_product(product_id, session)
    if not result["status"] == "success":
        raise HTTPException(status_code=404, detail=result["message"])
    return result
