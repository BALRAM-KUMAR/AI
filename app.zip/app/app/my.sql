-- drop all data everything

-- Disable foreign key checks temporarily (optional)
SET session_replication_role = 'replica';

-- Delete all records from the dependent tables first (to avoid foreign key constraint issues)
TRUNCATE TABLE notifications, comments, likes, post_tags, posts, user_roles, products, followers_association, profiles, roles, companies, colleges RESTART IDENTITY CASCADE;

-- After this, truncate the main 'users' table
TRUNCATE TABLE users RESTART IDENTITY CASCADE;

-- Enable foreign key checks back
SET session_replication_role = 'origin';



------------high level-----------------
SELECT 
    u.id AS user_id,
    u.name,
    u.email,
    p.*, 
    c.*, 
    co.*, 
    ps.*, 
    t.*, 
    l.*, 
    cm.*, 
    n.*, 
    f.follower_id,
    fw.followed_id
FROM 
    users u
LEFT JOIN profiles p ON u.id = p.user_id
LEFT JOIN colleges c ON p.college_id = c.id
LEFT JOIN companies co ON p.company_id = co.id
LEFT JOIN posts ps ON u.id = ps.user_id
LEFT JOIN post_tags pt ON ps.id = pt.post_id
LEFT JOIN tags t ON pt.tag_id = t.id
LEFT JOIN likes l ON ps.id = l.post_id
LEFT JOIN comments cm ON ps.id = cm.post_id
LEFT JOIN notifications n ON u.id = n.user_id
LEFT JOIN followers_association f ON f.followed_id = u.id
LEFT JOIN followers_association fw ON fw.follower_id = u.id
WHERE 
    u.id = 57;
