# schemas.py

from pydantic import BaseModel
from datetime import datetime

class RoleOut(BaseModel):
    id: int
    role_name: str
    description: str | None = None
    created_on: datetime
    updated_on: datetime

    class Config:
        from_attributes = True  # This tells Pydantic to serialize ORM models (SQLAlchemy) automatically
