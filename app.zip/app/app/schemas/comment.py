# schemas.py

from typing import Optional
from pydantic import BaseModel
from datetime import datetime

class CommentCreate(BaseModel):
    content: str
    parent_id: Optional[int] = None 

class CommentUpdate(BaseModel):
    content: str
    parent_id: Optional[int] = None 

class CommentResponse(BaseModel):
    id: int
    user_id: int
    post_id: int
    content: str
    created_on: datetime
    updated_on: datetime

    class Config:
        from_attributes = True
