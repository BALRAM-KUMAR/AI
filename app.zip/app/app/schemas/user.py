from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    user_name: str  # This should match the key you're sending
    email: str
    mobile_number: str
    password : str

class UserOut(BaseModel):
    id: int
    name: str
    email: str
    mobile_number: str
    password : str

    class Config:
        from_attributes = True  # Enables compatibility with SQLAlchemy models
