# schemas/like.py

from pydantic import BaseModel
from datetime import datetime

class LikeResponse(BaseModel):
    id: int
    user_id: int
    post_id: int
    created_on: datetime

    class Config:
        from_attributes = True
