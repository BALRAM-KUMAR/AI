import os
import logging
import configparser
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define paths
root_dir = os.path.dirname(os.path.abspath(__file__))
config_path = os.path.join(root_dir, 'config.ini')

# Load configuration
config = configparser.ConfigParser()
env = os.getenv('APP_ENV', 'development')  # Default to 'development' if not set

if os.path.exists(config_path):
    logger.info(f"Loading configuration from '{config_path}' for environment '{env}'")
    config.read(config_path)
else:
    logger.warning(f"Configuration file '{config_path}' not found. Using fallback values.")

# Helper to fetch configuration values
def get_config_value(section, key, fallback=None):
    try:
        return config.get(section, key, fallback=fallback)
    except (configparser.NoSectionError, configparser.NoOptionError) as e:
        logger.error(f"Missing key: [{section}] {key}. Fallback: {fallback}. Error: {e}")
        return fallback

# Environment-specific configurations
DATABASE_URL = get_config_value(env, 'DATABASE_URL', 'sqlite+aiosqlite:///default.db')
SECRET_KEY = get_config_value(env, 'SECRET_KEY', 'default_secret')
ALGORITHM = get_config_value(env, 'ALGORITHM', 'HS256')
ACCESS_TOKEN_EXPIRE_MINUTES = int(get_config_value(env, 'ACCESS_TOKEN_EXPIRE_MINUTES', 30))
REDIS_HOST = get_config_value(env, 'REDIS_HOST', 'localhost')
REDIS_PORT = int(get_config_value(env, 'REDIS_PORT', 6379))
REDIS_PASSWORD = get_config_value(env, 'REDIS_PASSWORD', None)
CELERY_BROKER_URL = get_config_value(env, 'CELERY_BROKER_URL', f'redis://{REDIS_HOST}:{REDIS_PORT}/0')
CELERY_BACKEND_URL = get_config_value(env, 'CELERY_BACKEND_URL', f'redis://{REDIS_HOST}:{REDIS_PORT}/0')

# Log loaded configuration (excluding sensitive data)
logger.info(f"Loaded configuration for environment: {env}")
logger.info(f"DATABASE_URL: {DATABASE_URL}")
logger.info(f"REDIS_HOST: {REDIS_HOST}, REDIS_PORT: {REDIS_PORT}")
