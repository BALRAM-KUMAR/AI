from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import Role, UserRole, User
from fastapi import HTTPException, status
from schemas.role import RoleOut  # Import Pydantic model

class RoleService:

    @staticmethod
    async def get_all_roles(db: AsyncSession):
        # Retrieve all roles
        result = await db.execute(select(Role))
        roles = result.scalars().all()
        if not roles:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No roles found")
        
        # Return roles as Pydantic models
        return roles

    @staticmethod
    async def get_user_roles(user_id: int, db: AsyncSession):
        # Fetch user roles by user_id
        user_roles_query = await db.execute(
            select(Role).join(UserRole).filter(UserRole.user_id == user_id)
        )
        roles = user_roles_query.scalars().all()
        if not roles:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User has no roles assigned")
        
        # Return roles as Pydantic models
        return roles

    @staticmethod
    async def assign_role_to_user(user_id: int, role_name: str, db: AsyncSession):
        # Check if user exists
        user = await db.get(User, user_id)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        # Find role by name
        role_query = await db.execute(select(Role).filter(Role.role_name == role_name))
        role = role_query.scalars().first()
        if not role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")

        # Check if user already has this role
        user_role_query = await db.execute(
            select(UserRole).filter(UserRole.user_id == user_id, UserRole.role_id == role.id)
        )
        if user_role_query.scalars().first():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="User already has this role")

        # Assign role to user
        user_role = UserRole(user_id=user_id, role_id=role.id)
        db.add(user_role)
        await db.commit()
        return {"msg": "Role assigned successfully"}

    @staticmethod
    async def update_user_role(user_id: int, new_role_name: str, db: AsyncSession):
        # Fetch the user and role
        user = await db.get(User, user_id)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

        role_query = await db.execute(select(Role).filter(Role.role_name == new_role_name))
        new_role = role_query.scalars().first()
        if not new_role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Role not found")

        # Update the user's role
        user_role_query = await db.execute(select(UserRole).filter(UserRole.user_id == user_id))
        user_role = user_role_query.scalars().first()
        if not user_role:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User does not have any role to update")

        user_role.role_id = new_role.id
        await db.commit()
        return {"msg": "User role updated successfully"}