from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from models import Post, Tag, PostTag, College, Company
from typing import List
from fastapi import HTTPException


# Helper: Get or create a tag
async def get_or_create_tag(name: str, session: AsyncSession) -> Tag:
    try:
        result = await session.execute(select(Tag).where(Tag.name == name))
        tag = result.scalar_one_or_none()
        if tag:
            return tag
        new_tag = Tag(name=name)
        session.add(new_tag)
        await session.flush()  # Ensure the tag gets an ID
        return new_tag
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get or create tag: {str(e)}")


# Helper: Check if a college or company exists
async def get_college_or_company(entity_type: str, entity_id: int, session: AsyncSession):
    try:
        model = College if entity_type == "college" else Company
        stmt = select(model).where(model.id == entity_id)
        result = await session.execute(stmt)
        entity = result.scalar_one_or_none()
        if not entity:
            raise HTTPException(status_code=404, detail=f"{entity_type.capitalize()} with ID {entity_id} not found.")
        return entity
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error while checking {entity_type}: {str(e)}")


# Service: Create a new post
async def create_post(data: dict, session: AsyncSession) -> dict:
    try:
        tags = data.pop("tags", [])
        college_id = data.pop("college_id", None)
        company_id = data.pop("company_id", None)

        # Create the post
        post = Post(**data)

        # Add Tags if provided
        if tags:
            for tag_name in tags:
                tag = await get_or_create_tag(tag_name, session)
                post_tag = PostTag(post=post, tag=tag)
                session.add(post_tag)

        session.add(post)
        await session.flush()  # Generate Post ID

        # Associate College and Company if provided
        if college_id:
            await get_college_or_company("college", college_id, session)
            post.college_id = college_id

        if company_id:
            await get_college_or_company("company", company_id, session)
            post.company_id = company_id

        await session.commit()
        return {"message": "Post created successfully"}
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=f"Error while creating post: {str(e)}")


# Service: Update an existing post
async def update_post_by_user(post_id: int, user_id: int, data: dict, session: AsyncSession) -> dict:
    try:
        tags = data.pop("tags", [])
        college_id = data.pop("college_id", None)
        company_id = data.pop("company_id", None)

        # Fetch the post
        stmt = select(Post).where(Post.id == post_id, Post.user_id == user_id).options(selectinload(Post.tags))
        result = await session.execute(stmt)
        post = result.scalar_one_or_none()
        if not post:
            raise HTTPException(status_code=404, detail=f"Post with ID {post_id} not found.")

        # Update fields
        for key, value in data.items():
            if value is not None:  # Update only non-null fields
                setattr(post, key, value)

        # Update Tags if provided
        if tags:
            post.tags.clear()
            for tag_name in tags:
                tag = await get_or_create_tag(tag_name, session)
                post_tag = PostTag(post=post, tag=tag)
                session.add(post_tag)

        # Update College and Company if provided
        if college_id:
            await get_college_or_company("college", college_id, session)
            post.college_id = college_id

        if company_id:
            await get_college_or_company("company", company_id, session)
            post.company_id = company_id

        await session.commit()
        return {"message": "Post updated successfully"}
    except Exception as e:
        await session.rollback()
        raise HTTPException(status_code=500, detail=f"Error while updating post: {str(e)}")



# # Get posts by user ID
# async def get_posts_by_user_id(user_id: int, session: AsyncSession) -> List[Post]:
#     result = await session.execute(select(Post).options(selectinload(Post.tags)).where(Post.user_id == user_id))
#     return result.scalars().all()


# # Get posts by user and tag
# async def get_posts_by_user_and_tag(user_id: int, tag_name: str, session: AsyncSession) -> List[Post]:
#     tag = await get_or_create_tag(tag_name, session)
#     result = await session.execute(
#         select(Post).join(PostTag).options(selectinload(Post.tags)).where(Post.user_id == user_id, PostTag.tag_id == tag.id)
#     )
#     return result.scalars().all()
