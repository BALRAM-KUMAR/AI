from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.exc import NoResultFound
from fastapi import HTTPException
from cache.like_cache import get_like_cache, set_like_cache
from cache_queue.producer import enqueue_task
from cache.cache_update import update_post_cache

async def toggle_like(post_id: int, user_id: int, user_name: str, is_profile_public: bool) -> dict:
    """
    Toggles the like status of a post by a user.
    Updates the post cache for immediate UI feedback and enqueues tasks for batch processing.

    Parameters:
    - post_id (int): ID of the post being liked/unliked.
    - user_id (int): ID of the user performing the like/unlike action.
    - user_name (str): Name of the user performing the action.
    - is_profile_public (bool): Whether the user's profile is public.

    Returns:
    - dict: A message indicating the action performed.
    """
    like_key = f"like:{post_id}:{user_id}"
    cache_key = f"user_posts:{user_id}"
    public_cache_key = f"public_posts"
    cached_like = await get_like_cache(like_key)

    # Determine current like status
    is_liked = cached_like if cached_like is not None else False

    user_info = {
        "user_id": user_id,
        "user_name": user_name if is_profile_public else "Anonymous",
    }

    # Toggle the like status
    if is_liked:
        await set_like_cache(like_key, False)  # Update like status in Redis
        await enqueue_task("remove_like", {"post_id": post_id, "user_id": user_id})

        # Update post cache to reflect the "unlike"
        await update_post_cache(
            post_id, cache_key,
            {"likes": {"action": "remove", "user_info": user_info}},
        )

        await update_post_cache(
            post_id, public_cache_key,
            {"likes": {"action": "remove", "user_info": user_info}},
        )

        return {"message": "Like removed"}
    else:
        await set_like_cache(like_key, True)  # Update like status in Redis
        await enqueue_task("add_like", {"post_id": post_id, "user_id": user_id})

        # Update post cache to reflect the "like"
        await update_post_cache(
            post_id,cache_key,
            {"likes": {"action": "add", "user_info": user_info}},
        )

        await update_post_cache(
            post_id,public_cache_key,
            {"likes": {"action": "add", "user_info": user_info}},
        )

        return {"message": "Like added"}





# # Remove a like for a specific post by a user
# async def remove_like(post_id: int, user_id: int, session: AsyncSession):
#     # Check if the like exists in Redis cache first
#     like_key = f"like:{post_id}:{user_id}"
#     existing_like = await get_like_cache(like_key)
    
#     if not existing_like:
#         raise HTTPException(status_code=404, detail="Like not found")

#     # Remove the like from the database
#     stmt = select(Like).filter(Like.post_id == post_id, Like.user_id == user_id)
#     result = await session.execute(stmt)
#     like = result.scalar_one_or_none()

#     if not like:
#         raise HTTPException(status_code=404, detail="Like not found")

#     # Remove the like from the database
#     await session.delete(like)
#     await session.commit()

#     # Remove the like from Redis cache
#     await set_like_cache(like_key, False)

#     return {"message": "Like removed"}























# # Get all likes for a specific post
# async def get_likes_for_post(post_id: int, session: AsyncSession):
#     result = await session.execute(select(Like).where(Like.post_id == post_id))
#     return result.scalars().all()

# # Get all likes made by a specific user
# async def get_likes_by_user(user_id: int, session: AsyncSession):
#     result = await session.execute(select(Like).where(Like.user_id == user_id))
#     return result.scalars().all()
