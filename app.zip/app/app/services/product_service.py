from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from models import Product
from typing import List, Optional


# Create a product for a specific user
async def create_product_for_user(user_id: int, product_data: dict, session: AsyncSession) -> Product:
    product_data["user_id"] = user_id  # Assign user_id from the route parameter
    new_product = Product(**product_data)
    session.add(new_product)
    await session.commit()
    await session.refresh(new_product)
    return new_product

# Get all products
async def get_all_products(session: AsyncSession) -> List[Product]:
    result = await session.execute(select(Product).options(selectinload(Product.user)))
    return result.scalars().all()

# Create a product
async def create_product(product_data: dict, session: AsyncSession) -> Product:
    new_product = Product(**product_data)
    session.add(new_product)
    await session.commit()
    await session.refresh(new_product)
    return new_product

# Get a product by ID
async def get_product_by_id(product_id: int, session: AsyncSession) -> Optional[Product]:
    result = await session.execute(
        select(Product).options(selectinload(Product.user)).where(Product.id == product_id)
    )
    return result.scalar_one_or_none()

# Get products by user ID
async def get_products_by_user_id(user_id: int, session: AsyncSession) -> List[Product]:
    result = await session.execute(
        select(Product).options(selectinload(Product.user)).where(Product.user_id == user_id)
    )
    return result.scalars().all()

# Update a product
async def update_product(product_id: int, product_data: dict, session: AsyncSession) -> Optional[Product]:
    product = await get_product_by_id(product_id, session)
    if not product:
        return None

    for key, value in product_data.items():
        setattr(product, key, value)

    await session.commit()
    await session.refresh(product)
    return product

# Delete a product
async def delete_product(product_id: int, session: AsyncSession) -> dict:
    product = await get_product_by_id(product_id, session)
    if not product:
        return {"status": "error", "message": "Product not found"}

    await session.delete(product)
    await session.commit()
    return {"status": "success"}
