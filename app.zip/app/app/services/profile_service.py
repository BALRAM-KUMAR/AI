# services/profile_service.py

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import joinedload
from models import Profile
from sqlalchemy.exc import NoResultFound
from fastapi import HTTPException

async def get_profile_by_user_id(user_id: int, session: AsyncSession):
    try:
        result = await session.execute(
            select(Profile).where(Profile.user_id == user_id)
        )
        profile = result.scalars().first()
        if not profile:
            raise HTTPException(status_code=404, detail="Profile not found")
        return profile
    except NoResultFound:
        raise HTTPException(status_code=404, detail="Profile not found")

async def create_profile(user_id: int, profile_data: dict, session: AsyncSession):
    profile = Profile(user_id=user_id, **profile_data)
    session.add(profile)
    await session.commit()
    await session.refresh(profile)
    return profile

async def update_profile(user_id: int, profile_data: dict, session: AsyncSession):
    result = await session.execute(
        select(Profile).where(Profile.user_id == user_id)
    )
    profile = result.scalars().first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    for key, value in profile_data.items():
        setattr(profile, key, value)
    
    await session.commit()
    await session.refresh(profile)
    return profile

async def delete_profile(user_id: int, session: AsyncSession):
    result = await session.execute(
        select(Profile).where(Profile.user_id == user_id)
    )
    profile = result.scalars().first()
    if not profile:
        raise HTTPException(status_code=404, detail="Profile not found")
    
    await session.delete(profile)
    await session.commit()
    return {"detail": "Profile deleted successfully"}

async def get_all_profiles(session: AsyncSession):
    result = await session.execute(select(Profile))
    profiles = result.scalars().all()
    return profiles
