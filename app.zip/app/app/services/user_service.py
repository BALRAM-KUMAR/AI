# services/user_service.py
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import User, Role, UserRole, Post, User, Comment, Like, PostTag
from typing import List, Dict, Any

from schemas.user import UserCreate
from auth import get_password_hash, create_access_token, verify_password
from fastapi import HTTPException, status

from sqlalchemy.orm import selectinload, joinedload
from cache.user_cache import UserSpecific, PostSpecific, PublicPostDetails
from models import User, Profile, followers_association

class UserService:

    @staticmethod
    async def register_user(user_data: UserCreate, db: AsyncSession):
        # Check if the email already exists
        existing_user_query = await db.execute(select(User).filter(User.email == user_data.email))
        if existing_user_query.scalars().first():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

        # Hash the password
        hashed_password = get_password_hash(user_data.password)

        # Create a new user instance
        new_user = User(
            name=user_data.user_name,
            email=user_data.email,
            mobile_number=user_data.mobile_number,
            password=hashed_password
        )
        db.add(new_user)
        await db.commit()
        await db.refresh(new_user)

        # Assign a default role to the user
        default_role_query = await db.execute(select(Role).filter(Role.role_name == "user"))
        default_role = default_role_query.scalars().first()
        if not default_role:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Default role not found")

        user_role = UserRole(user_id=new_user.id, role_id=default_role.id)
        db.add(user_role)
        await db.commit()

        # Generate token
        token = create_access_token(data={"sub": str(new_user.id)})
        return {"user_id": new_user.id, "access_token": token}

    @staticmethod
    async def login_user(email: str, password: str, db: AsyncSession):
        # Fetch user by email
        user_query = await db.execute(select(User).filter(User.email == email))
        user = user_query.scalars().first()

        # Verify user exists and password matches
        if not user or not verify_password(password, user.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect username or password",
                headers={"WWW-Authenticate": "Bearer"},
            )

        # Generate token
        token = create_access_token(data={"sub": str(user.id)})
        return {"user_id": user.id, "access_token": token}


class UserDetails:
   
    @staticmethod
    async def fetch_user_details(user_id: int, session: AsyncSession) -> dict:
        """
        Fetches user details using caching to minimize database queries.
        """
        # Check cache first
        cached_data = await UserSpecific.get_user_cache(user_id)
        if cached_data:
            return cached_data

        # If cache miss, fetch from the database
        user_data = await _fetch_user_data_from_db(user_id, session)

        # Cache the fetched data
        if user_data:
            await UserSpecific.set_user_cache(user_id, user_data)

        return user_data


async def _fetch_user_data_from_db(user_id: int, session: AsyncSession) -> dict:
    """
    Fetches user details from the database.
    """
    result = await session.execute(
        select(User)
        .options(
            selectinload(User.profile).selectinload(Profile.college),
            selectinload(User.profile).selectinload(Profile.company),
            selectinload(User.session),
            selectinload(User.notifications),
        )
        .where(User.id == user_id)
    )
    user = result.scalars().first()

    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    followers = await _fetch_followers(user_id, session)
    following = await _fetch_following(user_id, session)
    return _build_user_data(user, followers, following)


async def _fetch_followers(user_id: int, session: AsyncSession) -> list:
    """
    Fetch followers with details.
    """
    followers_query = await session.execute(
        select(User)
        .join(followers_association, followers_association.c.follower_id == User.id)
        .where(followers_association.c.followed_id == user_id)
    )
    return [
        {
            "user_id": follower.id,
            "username": follower.name,
            "profile_pic": follower.profile.image if follower.profile else "default_image.jpg",
        }
        for follower in followers_query.scalars().all()
    ]


async def _fetch_following(user_id: int, session: AsyncSession) -> list:
    """
    Fetch following with details.
    """
    following_query = await session.execute(
        select(User)
        .join(followers_association, followers_association.c.followed_id == User.id)
        .where(followers_association.c.follower_id == user_id)
    )
    return [
        {
            "user_id": following_user.id,
            "username": following_user.name,
            "profile_pic": following_user.profile.image if following_user.profile else "default_image.jpg",
        }
        for following_user in following_query.scalars().all()
    ]


def _build_user_data(user, followers, following) -> dict:
    """
    Build a dictionary of user details.
    """
    return {
        "user": {
            "id": user.id,
            "name": user.name,
            "is_profile_public": user.is_profile_public,
            "created_on": user.created_on.isoformat(),
            "updated_on": user.updated_on.isoformat() if user.updated_on else None,
        },
        "profile": {
            "bio": user.profile.bio if user.profile else None,
            "image": user.profile.image if user.profile else None,
            "sex": user.profile.sex if user.profile else None,
            "college": {
                "university": user.profile.college.university if user.profile and user.profile.college else None,
                "college": user.profile.college.college if user.profile and user.profile.college else None,
                "school": user.profile.college.school if user.profile and user.profile.college else None,
                "state": user.profile.college.state if user.profile and user.profile.college else None,
                "district": user.profile.college.district if user.profile and user.profile.college else None,
            } if user.profile else None,
            "company": {
                "name": user.profile.company.name if user.profile and user.profile.company else None,
                "location": user.profile.company.location if user.profile and user.profile.company else None,
                "short_name": user.profile.company.short_names if user.profile and user.profile.company else None,
            } if user.profile else None,
        },
        "session": {
            "status": user.session.status if user.session else "offline",
            "last_active": user.session.last_active.isoformat() if user.session and user.session.last_active else None,
        },
        "notifications": [
            {
                "message": notification.message,
                "is_read": notification.is_read,
                "created_on": notification.created_on.isoformat(),
            }
            for notification in user.notifications
        ] or [],
        "followers": {
            "count": len(followers),
            "list": followers,
        },
        "following": {
            "count": len(following),
            "list": following,
        },
    }  



class PostService:
    @staticmethod
    async def fetch_posts(session: AsyncSession, filters=None, order_by=None, limit=None, offset=None):
        query = select(Post).options(
            selectinload(Post.user).selectinload(User.profile),
            selectinload(Post.tags).selectinload(PostTag.tag),
            selectinload(Post.comments).selectinload(Comment.user).selectinload(User.profile),  # Load user and profile for comments
            selectinload(Post.comments).selectinload(Comment.replies).selectinload(Comment.user).selectinload(User.profile),  # Load replies and user profiles
            selectinload(Post.likes).selectinload(Like.user),
        )
        
        # Apply filters if provided
        if filters:
            query = query.filter(*filters)
        
        # Apply ordering if provided
        if order_by is not None:  # Explicitly check for None
            query = query.order_by(order_by)
        
        # Apply limit and offset
        if limit is not None:
            query = query.limit(limit)
        
        if offset is not None:
            query = query.offset(offset)
        
        # Execute the query
        result = await session.execute(query)
        return result.scalars().all()

         
    
    @staticmethod
    async def format_post_data(post):
        # Helper to build comment hierarchy
        def build_comment_hierarchy(comments):
            comment_map = {comment.id: comment for comment in comments}
            root_comments = []

            for comment in comments:
                if comment.parent_id:  # If the comment is a reply
                    parent = comment_map.get(comment.parent_id)
                    if parent:
                        if not hasattr(parent, "replies"):  # Ensure parent has a replies list
                            parent.replies = []
                        parent.replies.append(comment)
                else:
                    root_comments.append(comment)

            # Recursively format comments
            def format_comment(comment):
                return {
                    "comment_id": comment.id,
                    "content": comment.content,
                    "author": comment.user.name if comment.user and comment.user.is_profile_public else "Anonymous",
                    "created_on": comment.created_on.isoformat(),
                    "replies": [format_comment(reply) for reply in getattr(comment, "replies", [])]
                }

            return [format_comment(comment) for comment in root_comments]

        return {
            "post_id": post.id,
            "post": post.is_post,
            "quote": post.is_quote,
            "visible_post": post.is_visible_in_profile,
            "title": post.title,
            "content": post.content,
            "bg_color": post.bg_color,
            "bg_image": post.bg_image,
            "song": post.song,
            "video": post.video,
            "created_on": post.created_on.isoformat(),
            "updated_on": post.updated_on.isoformat() if post.updated_on else None,
            "view_count": post.view_count,
            "author": {
                "user_id": post.user.id,
                "name": post.user.name if post.user.is_profile_public else "Anonymous",
                "profile_image": post.user.profile.image if post.user.is_profile_public and post.user.profile else "default_image.jpg",
            },
            "tags": [tag.tag.name for tag in post.tags],
            "likes_count": len(post.likes),
            "comments": build_comment_hierarchy(post.comments),
            "likes": [
                {
                    "user_id": like.user.id,
                    "user_name": like.user.name if like.user.is_profile_public else "Anonymous",
                }
                for like in post.likes
            ],
        }
                      

class UserPostService(PostService):
    @staticmethod
    async def get_user_posts(user_id: int, session: AsyncSession, page: int, page_size: int, sort_by: str) -> list:
        # Check cache first
        cached_posts = await UserSpecific.get_user_posts_cache(user_id, page, page_size, sort_by)
        if cached_posts:
            return cached_posts

        # Cache miss, fetch from database
        offset = (page - 1) * page_size
        order_by = Post.view_count.desc() if sort_by == "trending" else Post.created_on.desc()

        posts = await PostService.fetch_posts(
            session=session,
            filters=[Post.user_id == user_id],
            order_by=order_by,
            limit=page_size,
            offset=offset
        )
        formatted_posts = [await PostService.format_post_data(post) for post in posts]
        await UserSpecific.set_user_posts_cache(user_id,page, page_size, sort_by, formatted_posts)  # Cache the result
        return formatted_posts



class PublicPostService(PostService):
    @staticmethod
    async def get_public_posts(session: AsyncSession, page: int, page_size: int, sort_by: str):
        cached_posts = await PublicPostDetails.get_public_posts_cache(page, page_size, sort_by)
        if cached_posts:
            return cached_posts

        offset = (page - 1) * page_size
        order_by = Post.view_count.desc() if sort_by == "trending" else Post.created_on.desc()

        posts = await PostService.fetch_posts(
            session=session,
            order_by=order_by,
            limit=page_size,
            offset=offset
        )
        if not posts:
            raise HTTPException(status_code=404, detail="No public posts found")

        formatted_posts = [await PostService.format_post_data(post) for post in posts]
        await PublicPostDetails.set_public_posts_cache(page, page_size, sort_by, formatted_posts)
        return formatted_posts
    

class PostDetailsService(PostService):
    @staticmethod
    async def get_post_details(post_id: int, session: AsyncSession):
        cached_post = await PostSpecific.get_post_cache(post_id)
        if cached_post:
            return cached_post

        posts = await PostService.fetch_posts(session=session, filters=[Post.id == post_id])
        if not posts:
            raise HTTPException(status_code=404, detail="Post not found")

        formatted_post = await PostService.format_post_data(posts[0])
        await PostSpecific.set_post_cache(post_id, formatted_post)  # Cache the result
        return formatted_post

