from models import Comment, User
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from sqlalchemy.orm import selectinload
from sqlalchemy.exc import NoResultFound
from typing import List, Optional
from fastapi import HTTPException
from cache import get_redis_client
import json


async def create_comment_for_post(
    comment_data: dict,
    user_id: int,
    post_id: int,
    parent_id: Optional[int],
    session: AsyncSession
) -> Comment:
    """
    Creates a new comment or reply.

    Parameters:
    - `comment_data`: Dictionary containing the content of the comment.
    - `user_id`: ID of the user making the comment.
    - `post_id`: ID of the post to which the comment belongs.
    - `parent_id`: ID of the parent comment for replies, if any.
    - `session`: Database session.
    """
    # Remove parent_id from comment_data to prevent conflicts
    comment_data.pop("parent_id", None)
    
    # Create the new comment
    new_comment = Comment(
        **comment_data,
        user_id=user_id,
        post_id=post_id,
        parent_id=parent_id
    )

    session.add(new_comment)
    await session.commit()
    await session.refresh(new_comment)

    # Eagerly load related user information to avoid lazy-loading issues
    result = await session.execute(
        select(Comment)
        .options(selectinload(Comment.user))
        .filter(Comment.id == new_comment.id)
    )
    new_comment = result.scalar_one()

    # Update the Redis cache
    cache_key = f"user_posts:{user_id}"
    public_cache_key = f"public_posts"
    await update_comment_cache(user_id, post_id, new_comment, cache_key, session)

    await update_comment_cache(user_id, post_id, new_comment, public_cache_key, session)
    return new_comment


async def update_comment_cache(user_id: int, post_id: int, new_comment: Comment, cache_key: str, session: AsyncSession):
    """
    Update the Redis cache with the new comment for a specific post.

    Parameters:
    - `user_id`: ID of the user making the comment.
    - `post_id`: ID of the post to update.
    - `new_comment`: The newly created comment instance.
    - `cache_key`: Cache key for user posts.
    - `session`: Database session.
    """
    
    def add_reply_to_comment(comments, parent_id, reply_data):
        """Recursively add a reply to the appropriate comment."""
        for comment in comments:
            if comment["comment_id"] == parent_id:
                comment["replies"].append(reply_data)
                return True  # Reply added
            if "replies" in comment:  # Check for nested replies
                if add_reply_to_comment(comment["replies"], parent_id, reply_data):
                    return True  # Reply added in nested replies
        return False  # Reply not added

    try:
        # Get Redis client
        redis_client = await get_redis_client()
        if redis_client is None:
            print("Failed to connect to Redis.")
            return

        # Retrieve all fields in the hash
        all_fields = await redis_client.hgetall(cache_key)
        if not all_fields:
            print(f"No data found in cache for key {cache_key}.")
            return

        # Deserialize the list of posts
        found = False
        for field, data in all_fields.items():
            posts = json.loads(data)

            # Find the post by `post_id`
            post = next((p for p in posts if p["post_id"] == post_id), None)
            if post is None:
                continue  # Check next field if post not found

            found = True

            # Prepare the new comment structure
            new_comment_data = {
                "comment_id": new_comment.id,
                "content": new_comment.content,
                "author": new_comment.user.name if new_comment.user and new_comment.user.is_profile_public else "Anonymous",
                "created_on": new_comment.created_on.isoformat(),
                "replies": []
            }

            # Add the comment to the appropriate place
            if new_comment.parent_id:
                # It's a reply; find the parent comment and add it to its replies
                if not add_reply_to_comment(post.get("comments", []), new_comment.parent_id, new_comment_data):
                    print(f"No parent comment found for reply ID {new_comment.parent_id}.")
            else:
                # It's a top-level comment; append to the comments list
                post.setdefault("comments", []).append(new_comment_data)

            # Update the list of posts and serialize back
            updated_posts = json.dumps(posts)
            await redis_client.hset(cache_key, field, updated_posts)  # Write back to the dynamic cache key
            print(f"Cache updated for post_id {post_id} under key {cache_key} in field {field}.")
            break  # Exit loop after updating

        if not found:
            print(f"Post with ID {post_id} not found in cache for user {user_id}.")

    except Exception as e:
        print(f"Error updating comment cache: {e}")






async def fetch_post_comments(post_id: int, session: AsyncSession) -> List[Comment]:
    """
    Fetches comments for a given post, including replies.

    Parameters:
    - `post_id`: ID of the post for which comments are fetched.
    - `session`: Database session.

    Returns:
    List[Comment]: List of comments with replies.
    """
    query = await session.execute(
        select(Comment).where(Comment.post_id == post_id).options(selectinload(Comment.replies))
    )
    comments = query.scalars().all()

    return comments


async def get_comments_for_post(post_id: int, session: AsyncSession) -> List[Comment]:
    """
    Fetches all comments for a specific post.

    Parameters:
    - `post_id`: ID of the post.
    - `session`: Database session.

    Returns:
    List[Comment]: List of comments.
    """
    result = await session.execute(select(Comment).where(Comment.post_id == post_id))
    return result.scalars().all()


async def get_comment_by_id(comment_id: int, session: AsyncSession) -> Comment:
    """
    Fetches a specific comment by ID.

    Parameters:
    - `comment_id`: ID of the comment.
    - `session`: Database session.

    Returns:
    Comment: The retrieved comment.
    """
    try:
        result = await session.execute(select(Comment).where(Comment.id == comment_id))
        return result.scalar_one()
    except NoResultFound:
        raise HTTPException(status_code=404, detail="Comment not found")


async def update_comment_by_id(comment_id: int, user_id: int, updated_data: dict, session: AsyncSession) -> Comment:
    """
    Updates a specific comment by ID.

    Parameters:
    - `comment_id`: ID of the comment.
    - `user_id`: ID of the user attempting to update.
    - `updated_data`: The updated data for the comment.
    - `session`: Database session.

    Returns:
    Comment: The updated comment.
    """
    stmt = select(Comment).filter(Comment.id == comment_id)
    result = await session.execute(stmt)
    comment = result.scalar_one_or_none()

    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")

    if comment.user_id != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to update this comment")

    for key, value in updated_data.items():
        setattr(comment, key, value)

    await session.commit()
    return comment


async def delete_comment_by_id(comment_id: int, user_id: int, session: AsyncSession):
    """
    Deletes a specific comment by ID.

    Parameters:
    - `comment_id`: ID of the comment.
    - `user_id`: ID of the user attempting to delete.
    - `session`: Database session.
    """
    stmt = select(Comment).filter(Comment.id == comment_id)
    result = await session.execute(stmt)
    comment = result.scalar_one_or_none()

    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")

    if comment.user_id != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this comment")

    await session.delete(comment)
    await session.commit()
