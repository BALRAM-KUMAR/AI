from sqlalchemy import Table, Column, Integer, String, Text, DateTime, ForeignKey, Boolean, Float
from sqlalchemy.orm import relationship, backref
from datetime import datetime
from db import Base
from sqlalchemy import UniqueConstraint

followers_association = Table(
    'followers_association',
    Base.metadata,
    Column('follower_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('followed_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('created_on', DateTime, default=datetime.utcnow, nullable=False),
    UniqueConstraint('follower_id', 'followed_id', name='uq_follower_followed')
)

# User model
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    mobile_number = Column(String, nullable=True)
    password = Column(String, nullable=False)
    is_profile_public = Column(Boolean, default=True)

    created_on = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    # Relationships
    posts = relationship("Post", back_populates="user", lazy="selectin", cascade="all, delete-orphan")
    profile = relationship("Profile", uselist=False, back_populates="user", lazy="selectin")
    session = relationship("UserSession", uselist=False, back_populates="user", lazy="selectin")
    notifications = relationship("Notification", back_populates="user", lazy="selectin", cascade="all, delete-orphan")
    products = relationship("Product", back_populates="user")
    roles = relationship("UserRole", back_populates="user")
    
    followers = relationship(
        "User",
        secondary=followers_association,
        primaryjoin=id == followers_association.c.followed_id,
        secondaryjoin=id == followers_association.c.follower_id,
        backref=backref("following", lazy="selectin"),
        lazy="selectin",
    )


class Profile(Base):
    __tablename__ = "profiles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    bio = Column(Text, nullable=True)
    image = Column(String, nullable=True)
    sex = Column(String, nullable=True)
    college_id = Column(Integer, ForeignKey('colleges.id'), nullable=True)
    company_id = Column(Integer, ForeignKey('companies.id'), nullable=True)

    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="profile", lazy="selectin")
    college = relationship("College", back_populates="profiles", lazy="selectin")
    company = relationship("Company", back_populates="profiles", lazy="selectin")



class College(Base):
    __tablename__ = "colleges"

    id = Column(Integer, primary_key=True, index=True)
    university = Column(String, nullable=True)
    college = Column(String, nullable=True)
    school = Column(String, nullable=True)
    college_type = Column(String, nullable=True)
    state = Column(String, nullable=True)
    district = Column(String, nullable=True)

    profiles = relationship("Profile", back_populates="college")



class Company(Base):
    __tablename__ = "companies"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    short_names = Column(Text, nullable=True)
    location = Column(Text, nullable=True)

    profiles = relationship("Profile", back_populates="company")


class Post(Base):
    __tablename__ = "posts"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)

    song = Column(String, nullable=True)
    video = Column(String, nullable=True)
    content = Column(Text, nullable=False)
    bg_color = Column(String, nullable=True)
    title = Column(String)
    bg_image = Column(String, nullable=True)
    view_count = Column(Integer, default=0)
    is_post = Column(Boolean, default=True)
    is_quote = Column(Boolean, default=False)
    is_story = Column(Boolean, default=False)   #added for capture the story
    target_user = Column(String)
    is_visible_in_profile = Column(Boolean, default=True)  # User controls visibility

    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User", back_populates="posts", lazy='joined')
    tags = relationship("PostTag", back_populates="post", cascade="all, delete-orphan")
    likes = relationship("Like", back_populates="post", cascade="all, delete-orphan")
    comments = relationship("Comment", back_populates="post", cascade="all, delete-orphan")

class Comment(Base):
    __tablename__ = "comments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    post_id = Column(Integer, ForeignKey('posts.id'), index=True)
    parent_id = Column(Integer, ForeignKey('comments.id'), nullable=True)  # For nested comments
    content = Column(Text, nullable=False)

    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    user = relationship("User")
    post = relationship("Post", back_populates="comments")
    replies = relationship("Comment", backref=backref('parent', remote_side=[id]))  # Self-referencing relationship


class Like(Base):
    __tablename__ = "likes"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    post_id = Column(Integer, ForeignKey('posts.id'), index=True)

    created_on = Column(DateTime, default=datetime.utcnow)

    user = relationship("User")
    post = relationship("Post", back_populates="likes")


class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, index=True)
    role_name = Column(String, unique=True, nullable=False)
    description = Column(Text, nullable=True)

    created_on = Column(DateTime, default=datetime.utcnow)
    updated_on = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class UserRole(Base):
    __tablename__ = "user_roles"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    role_id = Column(Integer, ForeignKey('roles.id'), index=True)

    created_on = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="roles")
    role = relationship("Role")

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)

    is_gift = Column(Boolean, default=False)
    is_jewellery = Column(Boolean, default=False)
    image = Column(String, nullable=True)
    link = Column(String, nullable=True)
    name = Column(String, nullable=False)
    original_price = Column(Float, nullable=True)
    discount_price = Column(Float, nullable=True)

    created_on = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="products")

class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)

    created_on = Column(DateTime, default=datetime.utcnow)

    posts = relationship("PostTag", back_populates="tag")

class PostTag(Base):
    __tablename__ = "post_tags"

    post_id = Column(Integer, ForeignKey('posts.id'), primary_key=True, index=True)
    tag_id = Column(Integer, ForeignKey('tags.id'), primary_key=True, index=True)

    post = relationship("Post", back_populates="tags")
    tag = relationship("Tag", back_populates="posts")


# Session Model (Optional)
# This model can be used to track user availability for live chat or audio/video sessions.
class UserSession(Base):
    __tablename__ = "user_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    status = Column(String, default="offline")  # Options: 'online', 'offline', 'in_call'
    last_active = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", back_populates="session")


class Room(Base):
    __tablename__ = "rooms"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)  # Room identifier (can be user IDs combined for private chat)
    is_audio_call = Column(Boolean, default=False)  # Indicates if it's an audio room
    is_video_call = Column(Boolean, default=False)  # Indicates if it's a video room
    created_on = Column(DateTime, default=datetime.utcnow)


class RoomParticipant(Base):
    __tablename__ = "room_participants"

    id = Column(Integer, primary_key=True, index=True)
    room_id = Column(Integer, ForeignKey('rooms.id'), index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    joined_on = Column(DateTime, default=datetime.utcnow)

    room = relationship("Room")
    user = relationship("User")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'), index=True)
    message = Column(String)  # E.g., "Incoming call from User A"
    is_read = Column(Boolean, default=False)
    created_on = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")
